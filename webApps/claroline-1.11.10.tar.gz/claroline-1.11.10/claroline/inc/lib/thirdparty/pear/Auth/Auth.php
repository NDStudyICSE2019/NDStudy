<?php

include_once(PEAR_LIB_PATH . '/Auth.php');

?>