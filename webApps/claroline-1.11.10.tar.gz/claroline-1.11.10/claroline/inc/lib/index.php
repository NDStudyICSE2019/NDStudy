<?php // $Id: index.php 13709 2011-10-19 10:50:43Z abourguignon $

/**
 * CLAROLINE
 *
 * @copyright   (c) 2001-2011, Universite catholique de Louvain (UCL)
 */

header('Location:../../../');
