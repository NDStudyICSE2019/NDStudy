<?php

// moved to display

require_once dirname(__FILE__) . '/../display/stringbuffer.lib.php';
