<?php // $Id: import.lib.php 10249 2008-05-20 11:46:22Z zefredz $

if ( count( get_included_files() ) == 1 )
{
    die( 'The file ' . basename(__FILE__) . ' cannot be accessed directly, use include instead' );
}
