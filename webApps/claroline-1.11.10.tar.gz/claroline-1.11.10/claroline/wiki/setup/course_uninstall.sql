DROP TABLE IF EXISTS `__CL_COURSE__wiki_acls`;
DROP TABLE IF EXISTS `__CL_COURSE__wiki_pages`;
DROP TABLE IF EXISTS `__CL_COURSE__wiki_pages_content`;
DROP TABLE IF EXISTS `__CL_COURSE__wiki_properties`;