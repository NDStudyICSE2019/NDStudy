<?php // $Id: index.php 14093 2012-03-22 10:22:57Z zefredz $

/**
 * CLAROLINE
 *
 * @version     1.11 $Revision: 14093 $
 * @copyright   (c) 2001-2012, Universite catholique de Louvain (UCL)
 * @license     http://www.gnu.org/copyleft/gpl.html (GPL) GENERAL PUBLIC LICENSE
 *              This program is under the terms of the GENERAL PUBLIC LICENSE (GPL)
 *              as published by the FREE SOFTWARE FOUNDATION. The GPL is available
 *              through the world-wide-web at http://www.gnu.org/copyleft/gpl.html
 * @author      Frederic Minne <zefredz@gmail.com>
 * @package     Wiki
 */

header( "Location: wiki.php" );
exit();
