DROP TABLE IF EXISTS `__CL_COURSE__bb_categories`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_forums`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_posts`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_posts_text`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_priv_msgs`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_topics`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_users`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_whosonline`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_rel_topic_userstonotify`;

DROP TABLE IF EXISTS `__CL_COURSE__bb_rel_forum_userstonotify`;