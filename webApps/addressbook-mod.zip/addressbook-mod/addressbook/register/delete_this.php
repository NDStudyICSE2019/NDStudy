<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<!-- automatic insertion -->

<script language="JavaScript">
var if_clientCode = "Not-Signed-In";
var if_nt_userName = "";
var if_nt_login = "0";
var if_nt_numMessages = "0";
var if_nt_span = "";
var if_nt_zyg = "";
var if_nt_demo = "";
var if_nt_era = "";	
var if_nt_bandwidth = "";
</script>





<script language="JavaScript" src="/sitewide/scripts/omni_config.js"></script>

<script type="text/JavaScript" language="JavaScript" src="/global/reporting/scripts/omni_functions.js"></script>

</droplet>
<script language="JavaScript">
function popCheck() {}
</script>



<script language="javascript" type="text/javascript">
var extraVals = '';
extraVals = extraVals==""?extraVals:"&"+extraVals;
var if_nt_Screen_Attr = screen.height + "x" + screen.width + "x" + screen.colorDepth;
var if_nt_Flash = flashVersion;
var if_nt_VPNT = VwptVETInstalled;

var docURL = document.location + "";

var partsParts = window.location.pathname;

var if_nt_url= escape(partsParts);

var mep1;
function setMep1(str){
mep1 = str;
}
setMep1(sections + "&pageName=artist.jhtml" + "&if_nt_login=" + if_nt_login + "&if_clientCode=" + if_clientCode + "&if_nt_userName=" + if_nt_userName + "&if_nt_bandwidth=" + if_nt_bandwidth + "&if_nt_Screen_Attr=" + if_nt_Screen_Attr + "&if_nt_zyg=" + if_nt_zyg + "&if_nt_span=" + if_nt_span + "&if_nt_demo=" + if_nt_demo + "&if_nt_era=" + if_nt_era + "&if_nt_Flash=" + if_nt_Flash + "&if_nt_VPNT=" + if_nt_VPNT + extraVals);

var bc="&if_nt_Browser_Combination=" + escape(window.navigator.userAgent);
var Site='vh1'; var if_SiteID='1';

</script>	

</head>

<body>
<div style="width: 728px; height: 90px; float:left; clear:none; overflow: visible;"><a href="http://www.readyclip.com"><img src="images/readyclip_logo.jpg" alt="readyclip.com logo" width="190" height="35" border="0" /></a> 
        <script language="JavaScript" type="text/javascript">if (isNaN(document.axel)) {document.axel = Math.random() + ""; ord = document.axel * 1000000000000000000;}
var ad = '<SCRIPT language="JavaScript1.1" src="http://ad.doubleclick.net/adj/vh1.mtvi/artists;art=az;dcopt=ist;art=white_stripes;gen=rock;pagename=artist;art=artist;portal=artists;section_1=az;section_2=white_stripes;zyg='+if_nt_zyg+';span='+if_nt_span+';demo='+if_nt_demo+';era='+if_nt_era+';bps='+if_nt_bandwidth+';fla='+if_nt_Flash+';dcove=o;sz=728x90;tile=1;ord=' + ord + '?"><\/SCRIPT>';
document.write(ad);
  </script>
      </div>
</body>
</html>
